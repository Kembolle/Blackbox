##################################################
#						 #
# The Ultimate Nautilus and Nemo Scripts Pack	 #
# 						 #
# Creator:		Inameiname		 #
# Version: 1.1			 		 #
# Last modified: 	19 March 2014		 #
# License:		GPLv3+			 #
#						 #
#						 #
# Latest Changes:				 #
# 1.1 - 19/03/14 - Updated Avconvert.sh and 	 #
# Winetricks.sh, among others, added ExtractX.sh,#
# YouTube-Downloader.sh and a few others, and 	 #
# added a few more of my own scripts, including  #
# a couple using Peerflix for easy torrent link	 #
# streaming.					 #
# 1.0 - 13/02/14 - Initial Release		 #
##################################################

This is The Ultimate Nautilus and Nemo Scripts
Pack. I say this because these are scripts I have
collected/tweaked/created/updated for several
years. I figure it was time to finally share.
Many I have found through numerous websites,
while several I have written myself. Several have
been taken from the various packages on the
"Gnome-Look" (or its alternates) website.

Of the many I have taken from other sources, I
have tweaked some for my own purposes, as well as
directed some of its folders to the scripts'
folders themselves. As such, so long as you have
all the dependents installed, they should work
as is.

To use: it is as easy as copying and pasting
the scripts into your Nemo / Nautilus folders.
Having used in both Nautilus and Nemo, I have
included versions that should work for whichever
you may use.

'/home/$USER/.gnome2/nemo-scripts' folder
'/home/$USER/.gnome2/nautilus-scripts' folder

There are approximately 1,000 scripts in this
pack.

FYI, in case the generic "$USER" does not work
for you, (I've not tested all the scripts with
it), you can change it recursively to your
$YOUR_USERNAME by using the following command:

find . -type f -exec sed -i s/'home\/$USER'/'home\/$YOUR_USERNAME'/g {} +

﻿
