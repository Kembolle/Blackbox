#!/bin/bash

# Add to playlist totem.
##########################################################################
#                 Nautilus "AddToPlaylist(totem)" Script                 #
##########################################################################
# Created by mdh3ll                                                      #
# Emails: mdh3ll@gmail.com                                               #
##########################################################################

totem --enqueue $NAUTILUS_SCRIPT_SELECTED_URIS
    
