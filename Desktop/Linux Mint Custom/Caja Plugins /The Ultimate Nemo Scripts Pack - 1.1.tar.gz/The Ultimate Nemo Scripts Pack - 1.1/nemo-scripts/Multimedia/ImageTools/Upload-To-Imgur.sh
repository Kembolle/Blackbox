#!/usr/bin/env bash
echo -e "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS"| xargs --delimiter="\n" python /usr/share/uploadtoimgur/uploader.py
