#!/bin/bash
# script by Orlando De Giorgi

convert $1 -colorspace GRAY $1


