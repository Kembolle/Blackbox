#!/bin/bash

javaws /home/$USER/.gnome2/nemo-scripts/My_Scripts/Stopwatch/.stopwatch.jnlp
