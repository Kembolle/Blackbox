#!/bin/bash

/home/$USER/.gnome2/nemo-scripts/My_Scripts/For-Newbies/.delay.sh 10 "/usr/bin/python /home/$USER/.gnome2/nemo-scripts/My_Scripts/For-Newbies/For-Newbies.py"
