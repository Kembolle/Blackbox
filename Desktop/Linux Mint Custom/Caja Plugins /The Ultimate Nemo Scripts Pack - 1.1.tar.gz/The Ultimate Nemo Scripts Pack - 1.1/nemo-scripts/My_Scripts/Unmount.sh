#!/bin/bash
# unmount
# ubulal

gksudo umount "`echo "$NAUTILUS_SCRIPT_SELECTED_FILE_PATHS"`"
