#!/bin/bash

script-worker copy_to_xdg $NAUTILUS_SCRIPT_SELECTED_URIS XDG_DOWNLOAD_DIR
