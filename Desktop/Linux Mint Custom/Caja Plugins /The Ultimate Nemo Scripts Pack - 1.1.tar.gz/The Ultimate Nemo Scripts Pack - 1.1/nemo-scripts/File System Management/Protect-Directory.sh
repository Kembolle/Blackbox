#!/bin/bash
gksu "lock '$1'"
