#!/bin/bash

script-worker link $NAUTILUS_SCRIPT_SELECTED_URIS
