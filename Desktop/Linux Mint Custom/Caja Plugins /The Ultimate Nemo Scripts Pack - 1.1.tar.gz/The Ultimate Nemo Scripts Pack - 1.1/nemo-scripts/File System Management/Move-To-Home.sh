#!/bin/bash

script-worker move_to_xdg $NAUTILUS_SCRIPT_SELECTED_URIS HOME
