#!/bin/bash
echo
echo "  ~·~·~·~·~·~·~·~·~·~·~·~·~·"
echo " * Script By FrankRock.it *"
echo " ~·~·~·~·~·~·~·~·~·~·~·~··"
echo
chmod 700 "$@"

# By http://www.frankrock.it
# frankrock74@gmail.com

# Selezionare uno o piu file e fare click su CHMOD700.sh, i file saranno resi con permessi 700 all istante ;)
