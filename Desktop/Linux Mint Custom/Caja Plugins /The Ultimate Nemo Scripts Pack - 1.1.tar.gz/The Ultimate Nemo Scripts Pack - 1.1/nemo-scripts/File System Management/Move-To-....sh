#!/bin/bash

script-worker move $NAUTILUS_SCRIPT_SELECTED_URIS
