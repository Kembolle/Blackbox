#!/bin/sh
cd $NAUTILUS_SCRIPT_CURRENT_URI
ps2pdf $@