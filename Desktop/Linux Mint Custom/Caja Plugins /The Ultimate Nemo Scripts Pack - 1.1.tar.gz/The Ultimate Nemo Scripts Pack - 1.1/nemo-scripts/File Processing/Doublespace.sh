#!/bin/sh
#doublespace:  Double-spaces selected file(s)
#requires unix sed
for arg 
do
 (sed G "$arg") > ds-"$arg"
done
