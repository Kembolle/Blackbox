#!/bin/bash
gnorpm-auth -U $*
