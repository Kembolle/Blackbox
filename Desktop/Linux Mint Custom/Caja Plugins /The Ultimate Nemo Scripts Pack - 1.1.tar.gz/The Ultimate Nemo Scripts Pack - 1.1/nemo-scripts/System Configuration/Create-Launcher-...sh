#!/bin/sh

gnome-desktop-item-edit --create-new $NAUTILUS_SCRIPT_CURRENT_URI
