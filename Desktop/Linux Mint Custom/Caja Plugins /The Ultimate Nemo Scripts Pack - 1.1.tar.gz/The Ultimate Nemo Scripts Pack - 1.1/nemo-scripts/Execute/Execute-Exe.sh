#!/bin/sh
wine $@