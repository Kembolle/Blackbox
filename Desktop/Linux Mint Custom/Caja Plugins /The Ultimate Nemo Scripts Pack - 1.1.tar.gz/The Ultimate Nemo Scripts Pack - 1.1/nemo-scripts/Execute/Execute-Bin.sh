#!/bin/sh
chmod a+x $@
./$@
 